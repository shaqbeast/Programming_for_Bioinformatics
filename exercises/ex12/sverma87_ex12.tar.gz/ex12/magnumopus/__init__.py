from magnumopus.mapping import map_reads_to_ref
from magnumopus.ispcr import ispcr
from magnumopus.mapping import map_reads_to_ref

