from .sam import Read
from .sam import SAM